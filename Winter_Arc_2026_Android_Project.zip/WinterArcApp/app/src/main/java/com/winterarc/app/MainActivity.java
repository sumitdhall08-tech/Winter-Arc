package com.winterarc.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
    android.content.SharedPreferences p;
    TextView day,weight,protein,water,sleep;
    int dayNo(){ Calendar s=Calendar.getInstance(); s.set(2026,Calendar.OCTOBER,1,0,0,0); Calendar n=Calendar.getInstance(); long d=(n.getTimeInMillis()-s.getTimeInMillis())/(1000L*60*60*24)+1; return (int)Math.max(1,Math.min(92,d)); }
    public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);p=getSharedPreferences("winter",0);bind();refresh();}
    void bind(){day=findViewById(R.id.dayText);weight=findViewById(R.id.weightText);protein=findViewById(R.id.proteinText);water=findViewById(R.id.waterText);sleep=findViewById(R.id.sleepText);
      findViewById(R.id.workoutBtn).setOnClickListener(v->{p.edit().putBoolean("workout_"+dayNo(),true).apply(); Toast.makeText(this,"Workout completed ✓",Toast.LENGTH_SHORT).show();});
      findViewById(R.id.logBtn).setOnClickListener(v->showLog());
      findViewById(R.id.checklistBtn).setOnClickListener(v->showChecklist()); }
    void refresh(){int d=dayNo();day.setText("DAY "+d+" / 92");weight.setText("Weight: "+p.getString("weight_"+d,"—")+" kg");protein.setText("Protein: "+p.getString("protein_"+d,"0")+" / 180 g");water.setText("Water: "+p.getString("water_"+d,"0")+" / 4 L");sleep.setText("Sleep: "+p.getString("sleep_"+d,"0")+" hrs");}
    void showLog(){ LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL); int pad=24;l.setPadding(pad,pad,pad,pad); EditText w=e("Weight (kg)",""), pr=e("Protein (g)",""), wa=e("Water (L)",""), sl=e("Sleep (hrs)","");l.addView(w);l.addView(pr);l.addView(wa);l.addView(sl); new AlertDialog.Builder(this).setTitle("Today's Log").setView(l).setPositiveButton("SAVE",(d,x)->{int n=dayNo();p.edit().putString("weight_"+n,w.getText().toString()).putString("protein_"+n,pr.getText().toString()).putString("water_"+n,wa.getText().toString()).putString("sleep_"+n,sl.getText().toString()).apply();refresh();}).setNegativeButton("CANCEL",null).show(); }
    EditText e(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setInputType(2|8192);e.setPadding(8,8,8,8);return e;}
    void showChecklist(){String[] items=new String[92]; boolean[] checked=new boolean[92]; for(int i=0;i<92;i++){items[i]="Day "+(i+1);checked[i]=p.getBoolean("done_"+(i+1),false);} ListView lv=new ListView(this);ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_multiple_choice,items);lv.setAdapter(a);lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);for(int i=0;i<92;i++)lv.setItemChecked(i,checked[i]);new AlertDialog.Builder(this).setTitle("92-Day Checklist").setView(lv).setPositiveButton("SAVE",(d,x)->{android.content.SharedPreferences.Editor ed=p.edit();for(int i=0;i<92;i++)ed.putBoolean("done_"+(i+1),lv.isItemChecked(i));ed.apply();}).show();}
}
