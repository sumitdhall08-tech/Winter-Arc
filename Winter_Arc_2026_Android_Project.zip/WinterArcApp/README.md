# Winter Arc 2026 — Android App

Version 1 is an offline Android tracker based on the supplied Winter Arc 2026 planner.

Features:
- 92-day challenge dashboard
- Daily weight, protein, water and sleep logging
- Workout completion
- 92-day checklist
- Local on-device persistence via SharedPreferences
- Portrait mobile UI

Build with Android Studio using JDK 17 and Android SDK 35. The Gradle project uses Android Gradle Plugin 8.7.3.
